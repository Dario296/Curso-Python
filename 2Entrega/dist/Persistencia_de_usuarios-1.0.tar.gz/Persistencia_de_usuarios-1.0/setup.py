from setuptools import setup 

setup(
    name='Persistencia_de_usuarios',
    version="1.0",
    description="Primer paquete dist para crear usuarios",
    author="Dario Rodriguez",
    author_email="dariorodriguez296@yahoo.com.ar",
    packages=['Persistencia']
)